Shantz XWinWrap
A project by Shantanu Goel (http://tech.shantanugoel.com)
Visit the project's home page (http://tech.shantanugoel.com/projects/linux/shantz-xwinwrap) for usage details, feature requests and other queries
How to install:
1. Choose a folder from this zip file as per your distribution. If you have a 32 bit operating system, go into folder "i386". If you have a 64 bit OS, go into folder "x86_64".
2. Now, if you have debian (or a debian derived OS like Ubuntu, Mepis, etc), then you can just double click on the deb package within the folder to install shantz-xwinwrap, otherwise, just copy the xwinwrap binary file to any folder you want (preferably /usr/bin) and use it from there.
